#!/usr/bin/env python3
"""
CLI tool: find the PDF page most similar to a query.
Uses TF-IDF + cosine similarity (fully offline, no API key needed).

Usage:
    python search_pdf.py --pdf book.pdf --query "how do for loops work"
    python search_pdf.py --pdf book.pdf --query "recursion" --top-k 3
"""
import argparse
import sys

from pypdf import PdfReader
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


def load_pages(pdf_path):
    """Return a list of page texts (index 0 = page 1)."""
    try:
        reader = PdfReader(pdf_path)
    except FileNotFoundError:
        sys.exit(f"Error: file not found: {pdf_path}")
    except Exception as e:
        sys.exit(f"Error: could not read PDF: {e}")

    pages = []
    for page in reader.pages:
        text = page.extract_text() or ""
        pages.append(" ".join(text.split()))  # normalize whitespace
    return pages


def search(pages, query, top_k=1):
    """Return list of (page_number, score) sorted by similarity, best first."""
    vectorizer = TfidfVectorizer(
        stop_words="english",
        ngram_range=(1, 2),
        sublinear_tf=True,
    )
    page_matrix = vectorizer.fit_transform(pages)
    query_vec = vectorizer.transform([query])
    scores = cosine_similarity(query_vec, page_matrix).ravel()

    ranked = scores.argsort()[::-1][:top_k]
    return [(int(i) + 1, float(scores[i])) for i in ranked]


def main():
    parser = argparse.ArgumentParser(
        description="Find the PDF page most similar to a query."
    )
    parser.add_argument("--pdf", required=True, help="Path to the PDF file")
    parser.add_argument("--query", required=True, help="Search query")
    parser.add_argument("--top-k", type=int, default=1,
                        help="Number of top pages to show (default: 1)")
    parser.add_argument("--max-chars", type=int, default=1500,
                        help="Max characters of page text to print (0 = all)")
    args = parser.parse_args()

    pages = load_pages(args.pdf)
    non_empty = sum(1 for p in pages if p.strip())
    if non_empty == 0:
        sys.exit("Error: no selectable text found (is this a scanned PDF?).")

    print(f"Loaded {len(pages)} pages ({non_empty} with text).\n")

    results = search(pages, args.query, args.top_k)
    for rank, (page_no, score) in enumerate(results, start=1):
        if score == 0:
            print("No matching page found for this query.")
            break
        text = pages[page_no - 1]
        if args.max_chars and len(text) > args.max_chars:
            text = text[: args.max_chars] + " ..."
        print("=" * 70)
        print(f"Rank {rank} | Page {page_no} | Similarity: {score:.4f}")
        print("=" * 70)
        print(text)
        print()


if __name__ == "__main__":
    main()
