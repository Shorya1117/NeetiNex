# PDF Page Similarity Search (CLI)

A command line tool that takes a PDF with selectable text and a query, and prints the page number (and the text) of the page most similar to the query.

## How it works

1. Text is extracted from every page using `pypdf`.
2. Each page and the query are converted into TF-IDF vectors (unigrams and bigrams, English stop words removed).
3. Cosine similarity is computed between the query and every page.
4. The highest scoring page(s) are printed with their page number, score and text.

Everything runs offline. No API key or `.env` file is needed.

## Requirements

- Linux with Python 3.9+
- A PDF with selectable text (not a scanned image)

## Setup

```bash
sudo apt update
sudo apt install -y python3 python3-venv python3-pip curl

mkdir -p ~/pdf_search && cd ~/pdf_search
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

`requirements.txt`:

```
pypdf
scikit-learn
```

## Get a PDF

Example (the free book *Think Python*):

```bash
curl -L -o book.pdf https://greenteapress.com/thinkpython2/thinkpython2.pdf
```

Or copy your own PDF into the folder as `book.pdf`.

## Usage

```bash
python search_pdf.py --pdf book.pdf --query "what is a recursive function"
```

Options:

| Option | Description | Default |
|---|---|---|
| `--pdf` | Path to the PDF file | required |
| `--query` | Search query | required |
| `--top-k` | Number of top pages to show | 1 |
| `--max-chars` | Max characters of page text to print (0 = all) | 1500 |

More examples:

```bash
python search_pdf.py --pdf book.pdf --query "dictionaries and hashing" --top-k 3
python search_pdf.py --pdf book.pdf --query "file handling" --max-chars 0
```

## Example output

```
Loaded 244 pages (240 with text).

======================================================================
Rank 1 | Page 85 | Similarity: 0.3412
======================================================================
<text of the matching page>
```

## Project structure

```
pdf_search/
├── search_pdf.py
├── requirements.txt
├── book.pdf
└── README.md
```

## Limitations

- TF-IDF matches on words, not meaning. A query using different wording than the page may rank poorly. Sentence embeddings (e.g. `sentence-transformers`) would improve this.
- Scanned PDFs without a text layer are not supported (the tool exits with an error).
